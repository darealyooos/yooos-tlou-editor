// Factions Reborn Prop Editor — browser side.
// Meshes and textures come from /api (decoded from the user's own TLOU Part II paks by WorldEditor/Core).
// Scenes are .frscene documents shared with the WPF World Editor.
import * as THREE from 'three';
import { OrbitControls } from './lib/OrbitControls.js';
import { TransformControls } from './lib/TransformControls.js';

const $ = (id) => document.getElementById(id);
const CATEGORIES = ['Buildings', 'Props', 'Vegetation', 'Objects'];
const DEG = Math.PI / 180;
const status = (t) => { $('status').textContent = t; };

// ------------------------------------------------------------------ api

async function api(url, opts) {
  const r = await fetch(url, opts);
  if (!r.ok) {
    let msg = `${r.status}`;
    try { const j = await r.json(); msg = j.detail || j.title || msg; } catch { msg = await r.text().catch(() => msg); }
    throw new Error(msg);
  }
  return r.headers.get('content-type')?.includes('json') ? r.json() : r.text();
}
const q = (o) => new URLSearchParams(Object.entries(o).filter(([, v]) => v !== null && v !== undefined)).toString();

// ------------------------------------------------------------------ meshes (shared templates)

const meshCache = new Map();
const texLoader = new THREE.TextureLoader();
const untextured = new THREE.MeshLambertMaterial({ color: 0x96968f, side: THREE.DoubleSide });

function assetKey(a) { return `${a.archive}|${a.path}|${a.proto ?? ''}`; }

function loadMesh(asset) {
  const key = assetKey(asset);
  if (!meshCache.has(key)) {
    meshCache.set(key, (async () => {
      const m = await api('/api/mesh?' + q({ archive: asset.archive, path: asset.path, proto: asset.proto }));
      const group = new THREE.Group();
      const materials = new Map();
      for (const s of m.submeshes) {
        const g = new THREE.BufferGeometry();
        g.setAttribute('position', new THREE.Float32BufferAttribute(s.positions, 3));
        if (s.uvs) g.setAttribute('uv', new THREE.Float32BufferAttribute(s.uvs, 2));
        g.setIndex(s.indices);
        g.computeVertexNormals();
        g.computeBoundingSphere();
        let mat = untextured;
        if (s.texture && s.uvs) {
          if (!materials.has(s.texture)) {
            const tex = texLoader.load('/api/texture?' + q({ archive: asset.archive, path: asset.path, name: s.texture }));
            tex.flipY = false;                        // D3D texture coordinates (origin top-left)
            tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
            tex.colorSpace = THREE.SRGBColorSpace;
            materials.set(s.texture, new THREE.MeshLambertMaterial({ map: tex, side: THREE.DoubleSide }));
          }
          mat = materials.get(s.texture);
        }
        group.add(new THREE.Mesh(g, mat));
      }
      return { group, info: m };
    })());
    meshCache.get(key).catch(() => meshCache.delete(key));
  } else {
    const v = meshCache.get(key); meshCache.delete(key); meshCache.set(key, v); // most recently used last
  }
  const result = meshCache.get(key);
  trimMeshCache(key);
  return result;
}

// Bounded template cache: browsing thousands of assets must not keep every geometry and texture on the GPU.
// Templates used by the scene (their clones share geometry/material) and the one being loaded are never evicted.
const MESH_CACHE_LIMIT = 40;
function trimMeshCache(keepKey) {
  if (meshCache.size <= MESH_CACHE_LIMIT) return;
  const inScene = new Set(doc.objects.map(o => assetKey({ archive: o.asset.archive, path: o.asset.path, proto: o.prototype ?? null })));
  for (const [key, pending] of meshCache) {
    if (meshCache.size <= MESH_CACHE_LIMIT) break;
    if (key === keepKey || key === previewKey || inScene.has(key)) continue;
    meshCache.delete(key);
    pending.then(({ group }) => disposeGroup(group)).catch(() => {});
  }
}

function disposeGroup(group) {
  group.traverse(o => {
    if (!o.isMesh) return;
    o.geometry?.dispose();
    if (o.material && o.material !== untextured) { o.material.map?.dispose(); o.material.dispose(); }
  });
}

// ------------------------------------------------------------------ main viewport

const canvas = $('view');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, preserveDrawingBuffer: true });
renderer.setPixelRatio(window.devicePixelRatio);
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x151916); // dusk charcoal (design tokens)
scene.add(new THREE.HemisphereLight(0xdfe6ee, 0x3a3328, 1.6));
const sun = new THREE.DirectionalLight(0xfff2e0, 1.6);
sun.position.set(-4, 10, -3);
scene.add(sun);
const grid = new THREE.GridHelper(100, 100, 0x4a5440, 0x2a3027);
scene.add(grid);
const camera = new THREE.PerspectiveCamera(55, 1, 0.05, 5000);
camera.position.set(6, 5, 8);
const orbit = new OrbitControls(camera, canvas);
orbit.target.set(0, 0.5, 0);
orbit.update();

const gizmo = new TransformControls(camera, canvas);
scene.add(gizmo.getHelper ? gizmo.getHelper() : gizmo);
gizmo.addEventListener('dragging-changed', (e) => { orbit.enabled = !e.value; if (!e.value) { showProperties(); markDirty(); } });
gizmo.addEventListener('objectChange', () => { const o = selectedObject(); if (o) { syncFromNode(o); showPropertiesValues(o); } });

function resize() {
  const w = canvas.clientWidth, h = canvas.clientHeight;
  if (canvas.width !== Math.floor(w * renderer.getPixelRatio()) || canvas.height !== Math.floor(h * renderer.getPixelRatio())) {
    renderer.setSize(w, h, false);
    camera.aspect = w / Math.max(1, h);
    camera.updateProjectionMatrix();
  }
}

// ------------------------------------------------------------------ preview

const pCanvas = $('preview');
const pRenderer = new THREE.WebGLRenderer({ canvas: pCanvas, antialias: true });
pRenderer.setPixelRatio(window.devicePixelRatio);
const pScene = new THREE.Scene();
pScene.background = new THREE.Color(0x181c19);
pScene.add(new THREE.HemisphereLight(0xdfe6ee, 0x3a3328, 1.6));
const pSun = new THREE.DirectionalLight(0xfff2e0, 1.6); pSun.position.set(-4, 10, 6); pScene.add(pSun);
const pCamera = new THREE.PerspectiveCamera(40, 1, 0.01, 1000);
const pOrbit = new OrbitControls(pCamera, pCanvas);
pOrbit.autoRotate = true; pOrbit.autoRotateSpeed = 2;
let previewNode = null, previewToken = 0;

let previewKey = null;
async function preview(asset, label) {
  const token = ++previewToken;
  previewKey = assetKey(asset);
  $('previewInfo').textContent = `Loading ${label}…`;
  try {
    const { group, info } = await loadMesh(asset);
    if (token !== previewToken) return;
    if (previewNode) pScene.remove(previewNode);
    previewNode = group.clone();
    pScene.add(previewNode);
    const box = new THREE.Box3().setFromObject(previewNode);
    const size = box.getSize(new THREE.Vector3()).length() || 1;
    const c = box.getCenter(new THREE.Vector3());
    pOrbit.target.copy(c);
    pCamera.position.copy(c).add(new THREE.Vector3(0.7, 0.45, 0.9).multiplyScalar(size));
    pCamera.near = size / 200; pCamera.far = size * 50; pCamera.updateProjectionMatrix();
    pOrbit.update();
    const textured = info.submeshes.filter(s => s.texture).length;
    $('previewInfo').textContent = `${label} — ${info.triangles.toLocaleString()} tris, ${info.submeshes.length} submesh(es), ${textured} textured` +
      (info.hasCollision ? ', has collision data' : '') + ` · ${info.path}`;
  } catch (e) {
    if (token === previewToken) $('previewInfo').textContent = `${label}: ${e.message}`;
  }
}

// ------------------------------------------------------------------ scene state

let doc = newDoc('Untitled arena');
const nodes = new Map();          // id -> THREE.Group
let selectedId = null;
let dirty = false;

function newDoc(name) {
  return { format: 'FactionsReborn.WorldEditor.Scene', version: 1, name, maps: [], objects: [], spawns: [], boundary: { points: [], minY: -10, maxY: 50 } };
}

function markDirty() { dirty = true; document.title = `* ${$('sceneName').value} — Factions Reborn Prop Editor`; }
function markClean() { dirty = false; document.title = `${$('sceneName').value} — Factions Reborn Prop Editor`; }

function selectedObject() { return doc.objects.find(o => o.id === selectedId) || null; }

function applyToNode(o) {
  const n = nodes.get(o.id);
  if (!n) return;
  n.position.fromArray(o.position);
  // Engine composes S * Rx * Ry * Rz * T with row vectors = three.js Euler order 'ZYX'.
  n.rotation.set(o.rotationDegrees[0] * DEG, o.rotationDegrees[1] * DEG, o.rotationDegrees[2] * DEG, 'ZYX');
  n.scale.fromArray(o.scale);
}

function syncFromNode(o) {
  const n = nodes.get(o.id);
  const r = (v) => Math.round(v * 1e4) / 1e4;
  o.position = n.position.toArray().map(r);
  o.rotationDegrees = [n.rotation.x, n.rotation.y, n.rotation.z].map(v => r(v / DEG));
  o.scale = n.scale.toArray().map(v => r(Math.max(0.01, v)));
}

async function addNode(o) {
  const root = new THREE.Group();
  root.userData.id = o.id;
  nodes.set(o.id, root);
  scene.add(root);
  applyToNode(o);
  try {
    const asset = { archive: o.asset.archive, path: o.asset.path, proto: o.prototype ?? null };
    const { group, info } = await loadMesh(asset);
    if (o.prototype != null && o.prototypeName && info.prototypeName !== o.prototypeName)
      throw new Error(`prototype #${o.prototype} is now '${info.prototypeName}', expected '${o.prototypeName}'`);
    root.add(group.clone());
  } catch (e) {
    const box = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshBasicMaterial({ color: 0xff3030, wireframe: true }));
    box.position.y = 0.5;
    root.add(box);
    status(`${o.name}: cannot load asset (${e.message}). Kept as a red box.`);
  }
  return root;
}

async function place(item, position) {
  const o = {
    id: crypto.randomUUID(),
    name: item.name,
    category: CATEGORIES.includes(item.category) ? item.category : 'Props',
    asset: { archive: item.archive, path: item.path },
    position: position.map(v => Math.round(v * 1e4) / 1e4),
    rotationDegrees: [0, 0, 0],
    scale: [1, 1, 1],
  };
  if (item.proto != null) { o.prototype = item.proto; o.prototypeName = item.prototypeName; }
  doc.objects.push(o);
  markDirty();
  await addNode(o);
  select(o.id);
  renderHierarchy();
  status(`Placed ${o.name} at (${o.position.map(v => v.toFixed(2)).join(', ')}).`);
  return o;
}

function removeSelected() {
  const o = selectedObject();
  if (!o) return;
  gizmo.detach();
  scene.remove(nodes.get(o.id));
  nodes.delete(o.id);
  doc.objects = doc.objects.filter(x => x !== o);
  selectedId = null;
  markDirty(); renderHierarchy(); showProperties();
}

async function duplicateSelected() {
  const o = selectedObject();
  if (!o) return;
  const c = structuredClone(o);
  c.id = crypto.randomUUID();
  c.name = o.name + ' copy';
  c.position = [o.position[0] + 1, o.position[1], o.position[2] + 1];
  doc.objects.push(c);
  await addNode(c);
  select(c.id);
  markDirty(); renderHierarchy();
}

function select(id) {
  selectedId = id;
  const n = id ? nodes.get(id) : null;
  if (n) gizmo.attach(n); else gizmo.detach();
  renderHierarchy();
  showProperties();
}

function focusSelected() {
  const n = selectedId ? nodes.get(selectedId) : null;
  const box = n ? new THREE.Box3().setFromObject(n) : (doc.objects.length ? boxOfAll() : null);
  if (!box || box.isEmpty()) return;
  const c = box.getCenter(new THREE.Vector3()), size = Math.max(1, box.getSize(new THREE.Vector3()).length());
  const dir = camera.position.clone().sub(orbit.target).normalize();
  orbit.target.copy(c);
  camera.position.copy(c).add(dir.multiplyScalar(size * 1.8));
  orbit.update();
}

/** Moves the grid and the drop plane under the scene's objects (scenes can sit at real map coordinates). */
function fitGround() {
  if (nodes.size === 0) { grid.position.set(0, 0, 0); ground.constant = 0; return; }
  const b = boxOfAll();
  if (b.isEmpty()) return;
  const c = b.getCenter(new THREE.Vector3());
  grid.position.set(Math.round(c.x), b.min.y, Math.round(c.z));
  ground.constant = -b.min.y;
}

function boxOfAll() {
  const b = new THREE.Box3();
  for (const n of nodes.values()) b.expandByObject(n);
  return b;
}

function setTool(mode) {
  gizmo.setMode(mode);
  for (const [id, m] of [['toolMove', 'translate'], ['toolRotate', 'rotate'], ['toolScale', 'scale']]) $(id).classList.toggle('on', m === mode);
}

function applySnap() {
  const on = $('snap').checked;
  gizmo.setTranslationSnap(on ? 0.25 : null);
  gizmo.setRotationSnap(on ? 15 * DEG : null);
  gizmo.setScaleSnap(on ? 0.1 : null);
}

// ------------------------------------------------------------------ picking + drop

const raycaster = new THREE.Raycaster();
const ground = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);

function rayFrom(clientX, clientY) {
  const r = canvas.getBoundingClientRect();
  raycaster.setFromCamera(new THREE.Vector2(((clientX - r.left) / r.width) * 2 - 1, -((clientY - r.top) / r.height) * 2 + 1), camera);
  return raycaster;
}

function pickObject(clientX, clientY) {
  const hits = rayFrom(clientX, clientY).intersectObjects([...nodes.values()], true);
  for (const h of hits) {
    let n = h.object;
    while (n && !n.userData.id) n = n.parent;
    if (n) return { id: n.userData.id, point: h.point };
  }
  return null;
}

function dropPoint(clientX, clientY) {
  const hit = pickObject(clientX, clientY);
  if (hit) return hit.point.toArray();
  const p = new THREE.Vector3();
  if (rayFrom(clientX, clientY).ray.intersectPlane(ground, p)) return p.toArray();
  return orbit.target.toArray();
}

let downAt = null;
canvas.addEventListener('pointerdown', (e) => { downAt = { x: e.clientX, y: e.clientY, onGizmo: gizmo.axis !== null }; });
canvas.addEventListener('pointerup', (e) => {
  if (!downAt || e.button !== 0) return;
  const moved = Math.hypot(e.clientX - downAt.x, e.clientY - downAt.y) > 4;
  if (!moved && !downAt.onGizmo) select(pickObject(e.clientX, e.clientY)?.id ?? null);
  downAt = null;
});

const wrap = $('viewWrap');
wrap.addEventListener('dragover', (e) => { if (e.dataTransfer.types.includes('application/x-fr-asset')) { e.preventDefault(); wrap.classList.add('dropping'); } });
wrap.addEventListener('dragleave', () => wrap.classList.remove('dropping'));
wrap.addEventListener('drop', async (e) => {
  wrap.classList.remove('dropping');
  const data = e.dataTransfer.getData('application/x-fr-asset');
  if (!data) return;
  e.preventDefault();
  await place(JSON.parse(data), dropPoint(e.clientX, e.clientY));
});

// ------------------------------------------------------------------ asset browser

let actors = [], levels = [], protoItems = [], tab = 'props', selectedItem = null;

function currentItems() { return tab === 'props' ? actors : protoItems; }

function renderAssets() {
  const words = $('search').value.toLowerCase().split(/\s+/).filter(Boolean);
  const all = currentItems().filter(i => words.every(w => i.name.toLowerCase().includes(w)));
  const shown = all.slice(0, 500);
  const ul = $('assets');
  ul.replaceChildren(...shown.map(item => {
    const li = document.createElement('li');
    li.draggable = true;
    li.innerHTML = `${escapeHtml(item.name)} <small>${escapeHtml(item.detail)}</small>`;
    li.title = `${item.path} (${item.archive})`;
    if (selectedItem === item) li.classList.add('sel');
    li.addEventListener('click', () => { selectedItem = item; renderAssets(); preview(item, item.name); });
    li.addEventListener('dblclick', () => place(item, orbit.target.toArray()));
    li.addEventListener('dragstart', (e) => { e.dataTransfer.setData('application/x-fr-asset', JSON.stringify(item)); e.dataTransfer.effectAllowed = 'copy'; });
    return li;
  }));
  $('assetCount').textContent = tab === 'protos' && protoItems.length === 0
    ? 'Load a map pak to list its prototypes (native buildings, walls, props).'
    : `${all.length} match(es)` + (all.length > shown.length ? ` — showing ${shown.length}, refine the filter` : '');
}

function renderLevels() {
  const words = $('levelSearch').value.toLowerCase().split(/\s+/).filter(Boolean);
  const list = levels.filter(l => words.every(w => l.name.toLowerCase().includes(w))).slice(0, 300);
  $('levelList').replaceChildren(...list.map((l, i) => {
    const o = document.createElement('option');
    o.value = levels.indexOf(l);
    o.textContent = `${l.name}  (${(l.size / 1048576).toFixed(1)} MB, ${l.archive.replace('.psarc', '')})`;
    if (i === 0) o.selected = true;
    return o;
  }));
}

async function loadLevelPrototypes() {
  const l = levels[$('levelList').value];
  if (!l) return;
  status(`Loading prototypes of ${l.name}… (large map paks take a few seconds)`);
  try {
    const protos = await api('/api/prototypes?' + q({ archive: l.archive, path: l.path }));
    protoItems = protos.map(p => ({
      name: p.shortName, detail: `#${p.index} ${l.name}`, category: p.category,
      archive: l.archive, path: l.path, proto: p.index, prototypeName: p.name,
    }));
    renderAssets();
    status(`${protoItems.length} prototypes in ${l.name}.`);
  } catch (e) { status(`Cannot load ${l.name}: ${e.message}`); }
}

function escapeHtml(s) { return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }

// ------------------------------------------------------------------ hierarchy + properties

function renderHierarchy() {
  const ul = $('hierarchy');
  const items = [];
  for (const cat of CATEGORIES) {
    const objs = doc.objects.filter(o => o.category === cat).sort((a, b) => a.name.localeCompare(b.name));
    const head = document.createElement('li');
    head.className = 'cat';
    head.textContent = `${cat} (${objs.length})`;
    items.push(head);
    for (const o of objs) {
      const li = document.createElement('li');
      li.className = 'obj' + (o.id === selectedId ? ' sel' : '');
      li.textContent = o.name;
      li.addEventListener('click', () => select(o.id));
      li.addEventListener('dblclick', () => { select(o.id); focusSelected(); });
      items.push(li);
    }
  }
  const extra = [];
  if (doc.maps?.length) extra.push(`${doc.maps.length} map(s)`);
  if (doc.spawns?.length) extra.push(`${doc.spawns.length} spawn(s)`);
  if (doc.boundary?.points?.length) extra.push('boundary');
  if (extra.length) {
    const li = document.createElement('li');
    li.className = 'cat';
    li.textContent = `Kept from World Editor (not shown here): ${extra.join(', ')}`;
    items.push(li);
  }
  ul.replaceChildren(...items);
}

function showProperties() {
  const o = selectedObject();
  const box = $('props');
  if (!o) { box.className = 'muted'; box.textContent = 'Nothing selected.'; return; }
  box.className = '';
  const vec = (label, key) => `<label>${label}</label><div class="vec">${[0, 1, 2].map(i => `<input data-key="${key}" data-i="${i}" type="number" step="any">`).join('')}</div>`;
  box.innerHTML = `
    <label>Name</label><input id="pName">
    <label>Category</label><select id="pCat">${CATEGORIES.map(c => `<option>${c}</option>`).join('')}</select>
    ${vec('Position (m)', 'position')}${vec('Rotation (deg, engine X→Y→Z)', 'rotationDegrees')}${vec('Scale', 'scale')}
    <p class="muted">${escapeHtml(o.asset.path)}<br>${escapeHtml(o.asset.archive)}${o.prototype != null ? `<br>prototype #${o.prototype}: ${escapeHtml(o.prototypeName ?? '')}` : ''}</p>`;
  $('pName').value = o.name;
  $('pCat').value = o.category;
  $('pName').addEventListener('change', (e) => { o.name = e.target.value; markDirty(); renderHierarchy(); });
  $('pCat').addEventListener('change', (e) => { o.category = e.target.value; markDirty(); renderHierarchy(); });
  box.querySelectorAll('.vec input').forEach(inp => inp.addEventListener('change', () => {
    const v = parseFloat(inp.value);
    if (!Number.isFinite(v)) return;
    o[inp.dataset.key][+inp.dataset.i] = inp.dataset.key === 'scale' ? Math.max(0.01, v) : v;
    applyToNode(o); markDirty();
  }));
  showPropertiesValues(o);
}

function showPropertiesValues(o) {
  $('props').querySelectorAll('.vec input').forEach(inp => {
    if (document.activeElement !== inp) inp.value = o[inp.dataset.key][+inp.dataset.i];
  });
}

// ------------------------------------------------------------------ scenes

async function refreshSceneList() {
  const names = await api('/api/scenes');
  $('sceneList').replaceChildren(new Option('Load scene…', ''), ...names.map(n => new Option(n, n)));
}

async function saveScene() {
  const name = $('sceneName').value.trim();
  if (!/^[A-Za-z0-9 _-]{1,80}$/.test(name)) { status('Scene name: letters, digits, space, _ and - only.'); return false; }
  doc.name = name;
  try {
    const r = await api('/api/scenes/' + encodeURIComponent(name), { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify(doc) });
    markClean();
    status(`Saved ${r.objects} object(s) to ${r.saved}`);
    await refreshSceneList();
    return true;
  } catch (e) { status(`Save failed: ${e.message}`); return false; }
}

function clearScene() {
  gizmo.detach();
  for (const n of nodes.values()) scene.remove(n);
  nodes.clear();
  selectedId = null;
}

async function loadScene(name) {
  if (dirty && !confirm('Discard unsaved changes?')) return;
  try {
    const r = await api('/api/scenes/' + encodeURIComponent(name));
    const d = typeof r === 'string' ? JSON.parse(r) : r;
    clearScene();
    doc = d;
    doc.objects ??= [];
    $('sceneName').value = doc.name || name;
    await Promise.all(doc.objects.map(addNode));
    renderHierarchy(); showProperties(); markClean();
    fitGround();
    focusSelected();
    status(`Loaded ${name}: ${doc.objects.length} object(s).`);
  } catch (e) { status(`Cannot load ${name}: ${e.message}`); }
}

// ------------------------------------------------------------------ wiring

$('toolMove').onclick = () => setTool('translate');
$('toolRotate').onclick = () => setTool('rotate');
$('toolScale').onclick = () => setTool('scale');
$('snap').onchange = applySnap;
$('btnSave').onclick = saveScene;
$('btnNew').onclick = () => {
  if (dirty && !confirm('Discard unsaved changes?')) return;
  clearScene(); fitGround(); doc = newDoc('Untitled arena'); $('sceneName').value = doc.name;
  renderHierarchy(); showProperties(); markClean();
};
$('sceneList').onchange = (e) => { if (e.target.value) loadScene(e.target.value); e.target.value = ''; };
let searchTimer = 0;
$('search').oninput = () => { clearTimeout(searchTimer); searchTimer = setTimeout(renderAssets, 90); }; // debounce typing
$('levelSearch').oninput = renderLevels;
$('btnLoadLevel').onclick = loadLevelPrototypes;
$('tabProps').onclick = () => { tab = 'props'; $('tabProps').classList.add('on'); $('tabProtos').classList.remove('on'); $('levelRow').hidden = true; renderAssets(); };
$('tabProtos').onclick = () => { tab = 'protos'; $('tabProtos').classList.add('on'); $('tabProps').classList.remove('on'); $('levelRow').hidden = false; renderLevels(); renderAssets(); };
window.addEventListener('beforeunload', (e) => { if (dirty) e.preventDefault(); });

window.addEventListener('keydown', (e) => {
  if (e.target.matches('input, select, textarea')) return;
  if (e.ctrlKey && e.key.toLowerCase() === 's') { e.preventDefault(); saveScene(); return; }
  if (e.ctrlKey && e.key.toLowerCase() === 'd') { e.preventDefault(); duplicateSelected(); return; }
  switch (e.key.toLowerCase()) {
    case 'w': setTool('translate'); break;
    case 'e': setTool('rotate'); break;
    case 'r': setTool('scale'); break;
    case 'f': focusSelected(); break;
    case 'delete': removeSelected(); break;
    case 'escape': select(null); break;
  }
});

function frame() {
  resize();
  orbit.update();
  renderer.render(scene, camera);
  const w = pCanvas.clientWidth, h = pCanvas.clientHeight;
  if (pCanvas.width !== Math.floor(w * pRenderer.getPixelRatio())) { pRenderer.setSize(w, h, false); pCamera.aspect = w / h; pCamera.updateProjectionMatrix(); }
  pOrbit.update();
  pRenderer.render(pScene, pCamera);
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

(async () => {
  try {
    status('Indexing game archives…');
    const s = await api('/api/status');
    if (!s.gameFound) { status('TLOU Part II not found. Start the server with TLOU2_DIR set to your game folder.'); return; }
    actors = (await api('/api/assets?kind=actor')).map(a => ({ ...a, detail: `${Math.round(a.size / 1024)} KB, ${a.archive.replace('.psarc', '')}` }));
    levels = await api('/api/assets?kind=level');
    renderAssets(); renderHierarchy(); await refreshSceneList(); markClean();
    status(`${s.actors} props and ${s.levels} map paks from ${s.buildDir}. Scenes: ${s.scenesDir}`);
  } catch (e) { status(`Startup failed: ${e.message}`); }
})();

// Read-only handle for automated checks in the browser console.
window.frEditor = { get doc() { return doc; }, nodes, place, select, saveScene, loadScene, setTool, get selectedId() { return selectedId; }, gizmo, camera };
