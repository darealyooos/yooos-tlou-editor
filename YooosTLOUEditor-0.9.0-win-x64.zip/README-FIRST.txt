﻿Yooos TLOU Editor 0.9.0 (framework-dependent, win-x64)
=================================================

An independent community tool. Not affiliated with or endorsed by Naughty Dog,
Sony Interactive Entertainment or PlayStation. No game content is included:
you need your own legally obtained copy of The Last of Us Part II Remastered (PC).

Run
  Desktop editor : YooosTLOUEditor.exe
  Web editor     : web\YooosTLOUEditor.Web.exe, then open http://127.0.0.1:5178

Requirements (framework-dependent build)
  .NET 10 Desktop Runtime (desktop editor)
  ASP.NET Core 10 Runtime (web editor)
  https://dotnet.microsoft.com/download/dotnet/10.0

Preferences, thumbnails and layout are stored in %LOCALAPPDATA%\YooosTLOUEditor.
Scenes (.frscene) default to Documents\Factions Reborn\Scenes.
Nothing is ever written into the game folder.

Licence: see LICENSE. Third-party components: see THIRD-PARTY-NOTICES.md.
